import apiUrls from '@/api/apiUrls';
import responseCode from '@/api/responseCode';
import request from '@/api/util/axios/request';

export { apiUrls, request, responseCode };
