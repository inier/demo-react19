

export default function Home() {
  return (
    <div>
      <h1>home</h1>
    </div>
  );
}
