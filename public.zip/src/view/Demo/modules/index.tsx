function Modules() {
  return <div>Modules</div>;
}

export default Modules;
